# baizi-plugin  ✨

## 📞 联系方式
- **作者**: baizi
- **QQ**: 2209176666
- **QQ群**: 863644536
- **tg群**: https://t.me/skyprozx
- **tg频道**: https://t.me/skyskyxz

### 介绍
我要介绍什么呢🤔

### 功能
- 一个适用于 [TRSS-Yunzai](https://github.com/TimeRainStarSky/Yunzai) 的自用小功能插件，基本上是无用功能

## 💡 安装教程

<details>
  <summary>展开/收起</summary>
）
#### 🔧Yunzai 根目录执行命令安装

#### 🔧 安装依赖
```bash
pnpm i
```

</details>

## 💤 使用说明

请使用 `#baizi/白子帮助`获取完整帮助

## 鸣谢

- [TRSS-Yunzai](https://gitee.com/TimeRainStarSky/Yunzai)
- [xh2580](https://github.com/xh2580)

## 其他

如果觉得此插件对你有帮助的话,可以点一个 star,你的支持就是不断更新的动力~