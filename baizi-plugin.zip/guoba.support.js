export function supportGuoba() {
    return {
    pluginInfo: {
        name: 'baizi-plugin',
        title: 'baizi插件',
        author: 'baizi',
        authorLink: '无',
        link: '不给🤓',
        isV3: true,
        isV2: false,
        description: '一个适用于Yunzai-Bot的小功能插件'
    }
    }
}