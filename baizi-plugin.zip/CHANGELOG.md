# 1.0.0
* baizi插件v1.0
